package com.cjkj.excel.api.service.impl;

import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.excel.api.dao.ExportInfoDao;
import com.cjkj.excel.api.entity.ExportInfo;
import com.cjkj.excel.api.service.ExportInfoService;
import org.springframework.stereotype.Service;


/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
@Service
public class ExportInfoServiceImpl extends SuperServiceImpl<ExportInfoDao, ExportInfo> implements ExportInfoService {

}
