package com.cjkj.excel.api.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description: 导出字段配置
 */
@Data
@TableName("export_config")
public class ExportConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId
    private String id;
    /**
     * 导出配置表主键
     */
    private String exportId;
    /**
     * 参数字段名
     */
    private String fieldName;
    /**
     * Excel字段名
     */
    private String excelName;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建人名称
     */
    private String createdByName;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updatedBy;
    /**
     * 更新人名称
     */
    private String updatedByName;
    /**
     * 更新时间
     */
    private Date updateTime;

}
