package com.cjkj.excel.api.feign;

import com.alibaba.fastjson.JSONObject;
import feign.RequestLine;
import org.springframework.web.bind.annotation.RequestBody;

import java.net.URI;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
public interface ImportFeignClient  {

    /**
     * post 请求
     * @param jsonObject
     * @return
     */
    @RequestLine("POST")
    JSONObject post(URI uri, @RequestBody JSONObject jsonObject);

    /**
     * GET请求
     * @param jsonObject
     * @return
     */
    @RequestLine("GET")
    JSONObject get(URI uri, @RequestBody JSONObject jsonObject);
}
