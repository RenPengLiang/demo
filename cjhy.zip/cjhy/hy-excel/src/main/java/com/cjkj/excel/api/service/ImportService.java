package com.cjkj.excel.api.service;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.excel.api.vo.ImportRes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */

public interface ImportService {
    /**
     * 导入Excel
     *
     * @param file
     * @param importId
     * @return
     */
    JSONObject importExcel(HttpServletRequest request, MultipartFile file, String importId);

    ImportRes get(String id);
}
