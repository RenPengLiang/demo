package com.cjkj.excel.api.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cjkj.common.exception.BusinessException;
import com.cjkj.excel.api.vo.ImportRes;
import com.cjkj.excel.api.entity.ImportConfig;
import com.cjkj.excel.api.entity.ImportInfo;
import com.cjkj.excel.api.service.ImportConfigService;
import com.cjkj.excel.api.service.ImportInfoService;
import com.cjkj.excel.api.service.ImportService;
import com.cjkj.excel.api.utils.HttpUtil;
import com.cjkj.excel.api.utils.SyncParseExcel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */

@Slf4j
@Service
public class ImportServiceImpl implements ImportService {
    @Resource
    private RestTemplate restTemplate;
    @Resource
    ImportConfigService importConfigService;
    @Resource
    ImportInfoService importInfoService;


    @Override
    public JSONObject importExcel(HttpServletRequest request, MultipartFile file, String importId) {
        if (!StringUtils.isNotBlank(importId) || file.isEmpty()) {
            throw new BusinessException("参数错误");
        }
        List<Map<Integer, String>> maps = SyncParseExcel.parseExcel(file, importId);
        if (maps.size() > 1) {
            List<ImportConfig> importConfigList = importConfigService.list(new QueryWrapper<ImportConfig>().lambda().eq(ImportConfig::getImportId, importId));
            JSONArray jsonArray = convertJson(maps, importConfigList);
            return importConfig(request, importId, jsonArray);
        }
        throw new BusinessException("解析错误");
    }

    @Override
    public ImportRes get(String id) {
        ImportInfo importInfo = importInfoService.getById(id);
        if (importInfo != null) {
            ImportRes importRes = new ImportRes();
            importRes.setId(importInfo.getId());
            importRes.setName(importInfo.getName());
            importRes.setTemplateUrl(importInfo.getTemplateUrl());
            return importRes;
        }
        return null;
    }

    /**
     * 根据key  组合主表字段  遍历excel的数据 将相同的组合keys合并  并拼接子表的数据
     *
     * @param list
     * @return
     */
    private JSONArray convertJson(List<Map<Integer, String>> excelListMap, List<ImportConfig> list) {
        List<Map<String, Object>> mainMapList = new ArrayList<>();
        for (int j = 1; j < excelListMap.size(); j++) {
            Map<String, Object> mainMap = new HashMap<String, Object>();
            Map<String, Map<String, String>> childMap = new HashMap<String, Map<String, String>>();
            Map<Integer, String> mapValue = excelListMap.get(j);
            StringBuilder keyValue = new StringBuilder();
            for (Integer i : mapValue.keySet()) {
                // 获取excel表头
                String excelName = excelListMap.get(0).get(i);
                // 获取对应excel表头配置属性
                List<ImportConfig> listExcel = list.stream().filter(o -> o.getExcelName().equals(excelName)).collect(Collectors.toList());
                if (listExcel.size() > 0) {
                    ImportConfig importConfig = listExcel.get(0);
                    if (importConfig.getSubField().equals("1")) {
                        // 如果字段配置为子表
                        if (childMap.containsKey(importConfig.getGroupId())) {
                            Map<String, String> singleMap = childMap.get(importConfig.getGroupId());
                            singleMap.put(importConfig.getFieldName(), mapValue.get(i));
                            childMap.put(importConfig.getGroupId(), singleMap);
                        } else {
                            Map<String, String> childMapValue = new HashMap<>();
                            childMapValue.put(importConfig.getFieldName(), mapValue.get(i));
                            childMap.put(importConfig.getGroupId(), childMapValue);
                        }
                    } else {
                        // 主表操作
                        mainMap.put(importConfig.getFieldName(), mapValue.get(i));
                        keyValue.append(importConfig.getFieldName() + "-" + mapValue.get(i) + ";");
                    }
                }
            }
            // 记录主表信息
            mainMap.put("import_main_key", keyValue);
            // 查询主表相关信息是否相同
            List<Map<String, Object>> maps = mainMapList.stream().filter(o -> o.get("key") != null && o.get("key").toString().equals(keyValue)).collect(Collectors.toList());
            Map<String, Object> map = null;
            if (maps.size() > 0) {
                map = maps.get(0);
            }
            // 循环子表记录
            for (String key : childMap.keySet()) {
                List<Map<String, String>> listChild = new ArrayList<>();
                if (map != null) {
                    listChild = (List<Map<String, String>>) map.get(key);
                    listChild.add(childMap.get(key));
                    map.put(key, listChild);
                } else {
                    listChild.add(childMap.get(key));
                    mainMap.put(key, listChild);
                }
            }
            if (map == null) {
                mainMapList.add(mainMap);
            }
        }
        for (Map<String, Object> map : mainMapList) {
            map.remove("import_main_key");
        }
        log.info(JSONArray.toJSONString(mainMapList));
        return JSONArray.parseArray(JSONArray.toJSONString(mainMapList));
    }

    private JSONObject importConfig(HttpServletRequest request, String importId, JSONArray jsonArray) {
        ImportInfo importInfo = importInfoService.getById(importId);
        String url = "http://" + importInfo.getServiceName() + importInfo.getServicePath();
        HttpHeaders requestHeaders = HttpUtil.getRequestHeaders(request);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("list", jsonArray);
        if (requestHeaders != null) {
            requestHeaders.remove("content-type");
            requestHeaders.remove("content-length");
        }
        requestHeaders.add("content-type", "application/json");
        HttpEntity<JSONObject> httpEntity = new HttpEntity<>(jsonObject, requestHeaders);
        JSONObject body = restTemplate.postForEntity(url, httpEntity, JSONObject.class).getBody();
        System.out.println(body);
        return body;
    }
}
