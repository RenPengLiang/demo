package com.cjkj.excel.api.utils;


import com.alibaba.excel.EasyExcel;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @description: easyexcel同步方法解析excel
 */
public class SyncParseExcel {


    public static List<Map<Integer, String>> parseExcel(MultipartFile file, String importId) {
        // 解析Excel
        List<Map<Integer, String>> listMap = new ArrayList<>();
        try {
            InputStream inputStream = file.getInputStream();
            //同步读取  读取表头
            listMap = EasyExcel.read(inputStream).sheet().headRowNumber(0).doReadSync();
        } catch (IOException e) {
            e.toString();
        }
        return listMap;
    }
}
