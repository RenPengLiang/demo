package com.cjkj.excel.api.feign.impl;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.excel.api.feign.ImportBuilderService;
import com.cjkj.excel.api.feign.ImportFeignClient;
import feign.Client;
import feign.Contract;
import feign.Feign;
import feign.codec.Decoder;
import feign.codec.Encoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClientsConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
@Service
@Import(FeignClientsConfiguration.class)
public class ImportBuilderServiceImpl implements ImportBuilderService {
    /**
     * 原生构造器
     */
    Feign.Builder builder;


    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    public ImportBuilderServiceImpl(Decoder decoder, Encoder encoder, Client client, Contract contract) {
        this.builder = Feign.builder()
                .client(client)
                .encoder(encoder)
                .decoder(decoder)
                .contract(contract);
    }

    @Override
    public JSONObject post(String serviceId, String baseUri, JSONObject jsonObject) throws URISyntaxException {
        ImportFeignClient importFeignClient = this.builder.target(ImportFeignClient.class, "http://" + serviceId);
        URI uri = new URI(baseUri);
        return importFeignClient.post(uri,jsonObject);
    }

    @Override
    public JSONObject get(String serviceId, String baseUri, JSONObject jsonObject) throws URISyntaxException {
        URI uri = new URI(baseUri);
        return this.builder.target(ImportFeignClient.class, "http://" + serviceId).get(uri,jsonObject);
    }
}
