package com.cjkj.excel.api.service.impl;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.util.DateUtils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cjkj.common.exception.BusinessException;
import com.cjkj.common.model.ResultData;
import com.cjkj.common.model.ReturnMsg;
import com.cjkj.common.redis.template.StringRedisUtil;
import com.cjkj.common.utils.DateUtil;
import com.cjkj.excel.api.dao.FileDownLogDao;
import com.cjkj.excel.api.entity.FileDownLog;
import com.cjkj.excel.api.vo.ExportRes;
import com.cjkj.excel.api.entity.ExportConfig;
import com.cjkj.excel.api.entity.ExportInfo;
import com.cjkj.excel.api.service.ExportAsyncService;
import com.cjkj.excel.api.service.ExportConfigService;
import com.cjkj.excel.api.service.ExportInfoService;
import com.cjkj.excel.api.utils.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.text.DecimalFormat;
import java.util.*;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
@Slf4j
@Service
@Configuration
public class ExportAsyncServiceImpl implements ExportAsyncService {

    @Resource
    StringRedisUtil stringRedisUtil;
    @Resource
    ExportInfoService exportInfoService;
    @Resource
    ExportConfigService exportConfigService;
    @Resource
    RestTemplate restTemplate;
    @Resource
    FileDownLogDao fileDownLogDao;

    private final String taskIdField = "exportTaskId";
    private final long daySeconds = 86400;
    private final String filePath = "/opt/excel/export/";

    @Value("${file.url}")
    String fileUrl;

    @Override
    @Async("asyncServiceExecutor")
    public void executeAsync(ExportRes exportRes, JSONObject jsonObject, HttpServletRequest request) {
        ExportInfo exportInfo = exportInfoService.getById(exportRes.getExportTaskId());
        List<ExportConfig> exportConfigs = exportConfigService.queryByExportId(exportRes.getExportTaskId());
        JSONArray jsonArray = list(exportInfo, jsonObject, request);
        exportRes.setPercent("50");
        exportRes.setName(exportInfo.getName());
        setTime(exportRes, new Date());
        stringRedisUtil.set(taskIdField + ":" + exportRes.getTaskId(), JSONObject.toJSONString(exportRes), daySeconds);
        log.info("查询个数：{}", (jsonArray != null ? jsonArray.size() : 0));
        log.info("下载进度信息：{}", JSONObject.toJSONString(exportRes));
        saveExcel(exportConfigs, exportRes, jsonArray, exportInfo);
        log.info("下载进度信息：{}", JSONObject.toJSONString(exportRes));
    }

    @Override
    public void excute(String taskId, JSONObject jsonObject, HttpServletResponse response, HttpServletRequest request) {
        ExportInfo exportInfo = exportInfoService.getById(taskId);
        List<ExportConfig> exportConfigs = exportConfigService.queryByExportId(taskId);
        JSONArray jsonArray = list(exportInfo, jsonObject, request);
        log.info("查询个数：" + jsonArray.size());
        responseExcel(exportInfo, exportConfigs, jsonArray, response);
    }

    private void responseExcel(ExportInfo exportInfo, List<ExportConfig> exportConfigs, JSONArray jsonArray, HttpServletResponse response) {
        String fileName = filePath + exportInfo.getName() + DateUtil.format(new Date(), "yyyyMMddHHmmss") + ".xlsx";
        List<List<String>> headList = new ArrayList<>();
        List<List<Object>> dataList = new ArrayList<>();
        for (ExportConfig exportConfig : exportConfigs) {
            List<String> head = new ArrayList<>();
            head.add(exportConfig.getExcelName());
            headList.add(head);
        }
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject jsonObject = (JSONObject) jsonArray.get(i);
            List<Object> data = new ArrayList<>();
            for (ExportConfig exportConfig : exportConfigs) {
                Object value = jsonObject.get(exportConfig.getFieldName());
                if (value != null) {
                    data.add(value);
                } else {
                    data.add("");
                }
            }
            dataList.add(data);
        }
        try {
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
            EasyExcel.write(response.getOutputStream())
                    // 这里放入动态头
                    .head(headList).sheet("sheet1")
                    // 当然这里数据用 List<List<String>> 去传入
                    .doWrite(dataList);
        } catch (Exception ex) {
            throw new BusinessException("读取文件流失败");
        }
    }

    /**
     * 设置时间
     *
     * @param exportRes
     * @param endTime
     */
    private void setTime(ExportRes exportRes, Date endTime) {
        try {
            Date startTime = DateUtils.parseDate(exportRes.getStartTime(), "yyyy-MM-dd HH:mm:ss");
            if (endTime != null) {
                exportRes.setEndTime(DateUtil.format(endTime, "yyyy-MM-dd HH:mm:ss"));
            }
            exportRes.setTimeStr(DateUtil.getDifferentTime(startTime, endTime));
        } catch (Exception e) {
            log.error("时间转换错误", e);
        }
    }

    /**
     * 保存excel
     *
     * @param exportConfigs
     * @param exportRes
     * @param jsonArray
     * @param exportInfo
     */
    private void saveExcel(List<ExportConfig> exportConfigs, ExportRes exportRes, JSONArray jsonArray, ExportInfo exportInfo) {
        String shortFileName = exportRes.getName() + DateUtil.format(new Date(), "yyyyMMddHHmmss") + new Random().nextInt(100) + ".xlsx";
        String fileName = filePath + shortFileName;
        log.info("文件临时生成路径：{}", fileName);
        List<List<String>> headList = new ArrayList<>();
        List<List<Object>> dataList = new ArrayList<>();
        for (ExportConfig exportConfig : exportConfigs) {
            List<String> head = new ArrayList<>();
            head.add(exportConfig.getExcelName());
            headList.add(head);
        }
        exportRes.setPercent("55");
        stringRedisUtil.set(taskIdField + ":" + exportRes.getTaskId(), JSONObject.toJSONString(exportRes), daySeconds);
        log.info("下载进度信息：{}", JSONObject.toJSONString(exportRes));
        Double dStep = 35.0 / jsonArray.size();
        Double dPercent = 55.0;
        DecimalFormat df = new DecimalFormat("0.00");
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject jsonObject = (JSONObject) jsonArray.get(i);
            List<Object> data = new ArrayList<>();
            for (ExportConfig exportConfig : exportConfigs) {
                Object value = jsonObject.get(exportConfig.getFieldName());
                if (value != null) {
                    data.add(value);
                } else {
                    data.add("");
                }
            }
            dPercent = dPercent + dStep;
            exportRes.setPercent(df.format(dPercent));
            setTime(exportRes, new Date());
            dataList.add(data);
            stringRedisUtil.set(taskIdField + ":" + exportRes.getTaskId(), JSONObject.toJSONString(exportRes), daySeconds);
        }
        log.info("下载进度信息：{}", JSONObject.toJSONString(exportRes));
        EasyExcel.write(fileName)
                // 这里放入动态头
                .head(headList).sheet("sheet1")
                // 当然这里数据用 List<List<String>> 去传入
                .doWrite(dataList);
        String url = updateLoadFile(fileName, exportInfo);
        // 文件下载记录
        this.insertDownLogInfo(url, shortFileName);
        log.info("返回下载进度信息：{}", JSONObject.toJSONString(exportRes));
        log.info("文件服务器上传接口调用后返回：{}", url);
        if (StringUtils.isEmpty(url)) {
            exportRes.setMessage("上传文件错误");
            stringRedisUtil.set(taskIdField + ":" + exportRes.getTaskId(), JSONObject.toJSONString(exportRes), daySeconds);
        } else {
            exportRes.setPercent("100");
            exportRes.setUrl(url);
            setTime(exportRes, new Date());
            stringRedisUtil.set(taskIdField + ":" + exportRes.getTaskId(), JSONObject.toJSONString(exportRes), daySeconds);
        }
        log.info("下载进度信息：{}", JSONObject.toJSONString(exportRes));
    }

    /**
     * 文件下载记录
     *
     * @param url
     * @param fileName
     */
    private void insertDownLogInfo(String url, String fileName) {
        if (!StringUtils.isEmpty(url)) {
            fileDownLogDao.insert(new FileDownLog() {{
              setFilePath(url);
              setFileName(fileName);
              setCreateTime(System.currentTimeMillis());
              // 1:成功
              setState(1);
            }});
            log.info("文件下载记录成功");
        }
    }

    /**
     * 调用接口获取数据结果
     *
     * @param exportInfo
     * @param jsonObject
     * @param request
     * @return
     */
    private JSONArray list(ExportInfo exportInfo, JSONObject jsonObject, HttpServletRequest request) {
        StringBuilder url = new StringBuilder("http://");
        url.append(exportInfo.getServiceName()).append(exportInfo.getServicePath());
        HttpHeaders requestHeaders = HttpUtil.getRequestHeaders(request);
        HttpEntity<JSONObject> httpEntity = new HttpEntity<>(jsonObject, requestHeaders);
        ResultData result = restTemplate.postForEntity(url.toString(), httpEntity, ResultData.class).getBody();
        log.info("请求查询接口返回：{}", JSONObject.toJSONString(result));
        if (result != null) {
            if (ReturnMsg.SUCCESS.getCode().equals(result.getCode())) {
                if (result.getData() instanceof List) {
                    log.info("excel数据查询返回数据：{}", JSONObject.toJSONString(result.getData()));
                    return JSONArray.parseArray(JSONObject.toJSONString(result.getData()));
                } else if (result.getData() instanceof HashMap) {
                    Map<String, Object> pageData = (HashMap) result.getData();
                    log.info("excel数据查询返回数据：{}", JSONObject.toJSONString(pageData.get("list")));
                    return JSONArray.parseArray(JSONObject.toJSONString(pageData.get("list")));
                }
            }
        }
        return null;
    }

    /**
     * 上传文件
     *
     * @param fileName
     * @param exportInfo
     * @return
     */
    private String updateLoadFile(String fileName, ExportInfo exportInfo) {
        RestTemplate restTemplate = new RestTemplate();
        // 设置请求头
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("multipart/form-data");
        headers.setContentType(type);
        // 设置请求体，注意是LinkedMultiValueMap
        FileSystemResource fileSystemResource = new FileSystemResource(fileName);
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        form.add("file", fileSystemResource);
        form.add("filename", fileName.replace(filePath, ""));
        form.add("apiKey", exportInfo.getApiKey());
        form.add("isRename", "0");
        // 用HttpEntity封装整个请求报文
        HttpEntity<MultiValueMap<String, Object>> files = new HttpEntity<>(form, headers);
        JSONObject jsonObject = restTemplate.postForObject(fileUrl, files, JSONObject.class);
        // 读取
        File file = new File(fileName);
        // 判断是否是文件夹
        if (file.isFile()) {
            // 删除
            file.delete();
        }
        if (jsonObject.get("code") != null && jsonObject.getString("code").equals(ReturnMsg.SUCCESS.getCode())) {
            Map<String, Object> map = ((HashMap) jsonObject.get("data"));
            if (map != null) {
                return map.get("url").toString();
            }
        }
        return null;
    }

}
