package com.cjkj.excel.api.utils;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedList;
import java.util.Map;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
public class NoModelDataListener extends AnalysisEventListener<Map<Integer, String>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NoModelDataListener.class);
    private static final int BATCH_COUNT = 5;
    LinkedList<Map<Integer, String>> list = new LinkedList<Map<Integer, String>>();

    @Override
    public void invoke(Map<Integer, String> data, AnalysisContext context) {
        synchronized (NoModelDataListener.class) {
            Integer rowIndex = context.readRowHolder().getRowIndex();
            LOGGER.info("解析到第" + rowIndex + "条数据:{}", JSON.toJSONString(data));
            list.add(data);
        }
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        synchronized (NoModelDataListener.class) {
            LOGGER.info("解析到一条头数据:{}", JSON.toJSONString(headMap));
            list.add(headMap);
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        System.out.println(list);
        LOGGER.info("所有数据解析完成！");
        list.clear();
    }

    /**
     * 加上存储数据库
     */
    private void saveData() {
        LOGGER.info("{}条数据，开始存储数据库！", list.size());
        LOGGER.info("存储数据库成功！");
    }


}
