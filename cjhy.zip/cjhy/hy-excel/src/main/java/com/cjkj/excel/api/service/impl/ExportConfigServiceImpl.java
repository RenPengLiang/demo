package com.cjkj.excel.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.excel.api.dao.ExportConfigDao;
import com.cjkj.excel.api.entity.ExportConfig;
import com.cjkj.excel.api.service.ExportConfigService;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
@Service
public class ExportConfigServiceImpl extends SuperServiceImpl<ExportConfigDao, ExportConfig> implements ExportConfigService {

    @Override
    public List<ExportConfig> queryByExportId(String exportId) {
        return super.list(new QueryWrapper<ExportConfig>()
                .lambda().eq(ExportConfig::getExportId, exportId));
    }
}
