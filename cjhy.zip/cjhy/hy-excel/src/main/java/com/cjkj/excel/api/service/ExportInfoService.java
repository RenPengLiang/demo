package com.cjkj.excel.api.service;

import com.cjkj.common.service.ISuperService;
import com.cjkj.excel.api.entity.ExportInfo;

/**
 * 导出配置
 *
 * @author: RenPL
 * @date: 2020/9/24 16:24
 */
public interface ExportInfoService extends ISuperService<ExportInfo> {

}

