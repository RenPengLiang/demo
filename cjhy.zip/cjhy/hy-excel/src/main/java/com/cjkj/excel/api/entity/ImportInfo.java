package com.cjkj.excel.api.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description: 导入配置
 */
@Data
@TableName("import_info")
public class ImportInfo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId
    private String id;
    /**
     * 名称
     */
    private String name;
    /**
     * 模板路径
     */
    private String templateUrl;
    /**
     * 服务名称
     */
    private String serviceName;
    /**
     * 服务访问地址
     */
    private String servicePath;
    /**
     * 创建人
     */
    private String createdBy;
    /**
     * 创建人名称
     */
    private String createdByName;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updatedBy;
    /**
     * 更新人名称
     */
    private String updatedByName;
    /**
     * 更新时间
     */
    private Date updateTime;

}
