package com.cjkj.excel.api.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description: 导入信息
 */
@Data
@ApiModel("导入信息")
public class ImportRes {
    /**
     * 主键
     */
    @ApiModelProperty("导入ID")
    private String id;
    /**
     * 名称
     */
    @ApiModelProperty("导入名称")
    private String name;
    /**
     * 模板路径
     */
    @ApiModelProperty("模板路径")
    private String templateUrl;
}
