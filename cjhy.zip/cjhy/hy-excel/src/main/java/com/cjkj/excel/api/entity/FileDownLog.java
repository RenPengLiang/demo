package com.cjkj.excel.api.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description: 文件下载记录
 */
@Data
@TableName("file_down_log")
public class FileDownLog implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value="id",type = IdType.AUTO)
    private String id;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 文件所在路径
     */
    private String filePath;
    /**
     * 创建时间
     */
    private Long createTime;
    /**
     * 更新时间
     */
    private Integer state;

}
