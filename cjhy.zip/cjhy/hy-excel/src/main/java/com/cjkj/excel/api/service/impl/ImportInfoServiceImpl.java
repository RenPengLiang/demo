package com.cjkj.excel.api.service.impl;

import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.excel.api.dao.ImportInfoDao;
import com.cjkj.excel.api.entity.ImportInfo;
import com.cjkj.excel.api.service.ImportInfoService;
import org.springframework.stereotype.Service;


@Service
public class ImportInfoServiceImpl extends SuperServiceImpl<ImportInfoDao, ImportInfo> implements ImportInfoService {

}
