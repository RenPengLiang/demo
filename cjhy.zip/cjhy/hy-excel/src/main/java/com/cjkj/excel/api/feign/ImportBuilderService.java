package com.cjkj.excel.api.feign;

import com.alibaba.fastjson.JSONObject;

import java.net.URISyntaxException;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @Description:
 */
public interface ImportBuilderService {
    /**
     *
     * @param baseUri
     * @param jsonObject
     * @return
     */
    JSONObject post(String serviceId, String baseUri, JSONObject jsonObject) throws URISyntaxException;

    /**
     *
     * @param baseUri
     * @param jsonObject
     * @return
     */
    JSONObject get(String serviceId, String baseUri, JSONObject jsonObject) throws URISyntaxException;
}
