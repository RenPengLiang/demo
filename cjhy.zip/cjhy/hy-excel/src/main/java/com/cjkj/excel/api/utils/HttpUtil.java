package com.cjkj.excel.api.utils;

import org.springframework.http.HttpHeaders;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

/**
 * @author: RenPL
 * @date: 2020/9/24 16:24
 * @description: 发送http请求工具类
 */
public class HttpUtil {

    /**
     * 获取请求头
     *
     * @param request
     * @return
     */
    public static HttpHeaders getRequestHeaders(HttpServletRequest request) {
        // 获取所有请求头名称
        Enumeration<String> headerNames = request.getHeaderNames();
        HttpHeaders requestHeaders = new HttpHeaders();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            // 根据名称获取请求头的值
            String value = request.getHeader(name);
            requestHeaders.add(name, value);
        }
        return requestHeaders;
    }
}
