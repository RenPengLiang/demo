package com.cjkj.generator.dao;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cjkj.common.mapper.SuperMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author RenPL
 * @Description:
 * @date 2019/11/30 15:03
 */
@Component
@Mapper
public interface CodeGeneratorDao extends SuperMapper {

    /**
     * 分页查询表结构信息列表
     *
     * @param page
     * @param map
     * @return
     */
    List<Map<String, Object>> queryList(Page<Map<String, Object>> page, @Param("p") Map<String, Object> map);

    /**
     * 查询表结构信息总条数
     *
     * @param map
     * @return
     */
    int queryTotal(Map<String, Object> map);

    /**
     * 根据表名查询表结构信息
     *
     * @param tableName
     * @return
     */
    Map<String, String> queryTable(String tableName);

    /**
     * 根据表名查询表的所有字段信息
     *
     * @param tableName
     * @return
     */
    List<Map<String, String>> queryColumns(String tableName);
}
