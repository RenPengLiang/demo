```
cjhy -- 网络货运平台
│  ├─hy-base -- 基础数据
│  │  ├─hy-base-dto -- 对外提供接口模块启动器，提供各类启动配置和 `Controller`
│  │  ├─hy-base-service -- 服务层，包含 Service Entity Mapper 等
│  │  ├─hy-base-web -- 接口
│  │─hy-code-generator -- 代码生成服务
│  ├─hy-excel -- excel导入导出服务
│  ├─hy-task -- 定时任务
```


