package com.cjkj.base.exception;

import com.cjkj.common.exception.GlobalExceptionAdvice;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description: 系统异常处理类，将系统异常统一格式化为系统JSON格式
 */
@RestControllerAdvice
public class CommonExceptionHandler extends GlobalExceptionAdvice {
	
}
