package com.cjkj.base.aspect;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.common.exception.BusinessException;
import com.cjkj.common.redis.template.StringRedisUtil;
import com.cjkj.common.utils.IPUtil;
import com.cjkj.base.annotation.NoRepeat;
import com.cjkj.log.monitor.LogUtil;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.time.LocalDateTime;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Aspect
@Component
public class NoRepeatAspect {
    @Autowired
    StringRedisUtil stringRedisUtil;

    @Pointcut("@annotation(com.cjkj.base.annotation.NoRepeat)")
    public void enterprisePointCut() {

    }

    @Around("enterprisePointCut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        HttpServletRequest request  = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String ip = IPUtil.getIpAddr(request);
        String token = request.getHeader("Authorization");
        LogUtil.info("token:" + token);
        // 获取注解
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        // 目标类、方法
        String className = method.getDeclaringClass().getName();
        String name = method.getName();

        String ipKey = "";
        NoRepeat noRepeat = method.getAnnotation(NoRepeat.class);
        if(noRepeat.checkBody()) {
            Object[] objs = joinPoint.getArgs();
            String body = "";
            if(objs.length>0){
                body = JSONObject.toJSONString(objs[0]);
            }
            ipKey = String.format("%s#%s#%s#%s", token, className, name, body);
        } else {
            ipKey = String.format("%s#%s#%s", token, className, name);
        }
        int hashCode = Math.abs(ipKey.hashCode());
        String key = String.format("%s_%d",ip,hashCode);
        LogUtil.info("ipKey={},hashCode={},key={}",ipKey,hashCode,key);
        long timeout = noRepeat.longTime();
        if (timeout < 0){
            //过期时间5分钟
            timeout = 60*5;
        }
        String value = stringRedisUtil.getStrValue(key);
        if (!StringUtils.isBlank(value)) {
            throw new BusinessException("请勿重复提交");
        }
        stringRedisUtil.set(key, LocalDateTime.now().toString(),timeout / 1000);
        return joinPoint.proceed();
    }
}
