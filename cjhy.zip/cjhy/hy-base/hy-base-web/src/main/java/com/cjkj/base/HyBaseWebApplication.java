package com.cjkj.base;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description: 启动类
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.cjkj.base.feign"})
@MapperScan("com.cjkj.base.dao")
public class HyBaseWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(HyBaseWebApplication.class, args);
    }

}
