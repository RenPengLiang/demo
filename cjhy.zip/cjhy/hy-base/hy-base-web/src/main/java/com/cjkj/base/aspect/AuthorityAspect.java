package com.cjkj.base.aspect;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.common.model.ReturnMsg;
import com.cjkj.base.annotation.Authority;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Aspect
@Component
public class AuthorityAspect {

    @Pointcut("@annotation(com.cjkj.base.annotation.Authority)")
    public void authorityPointCut() {

    }

    @Around("authorityPointCut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] objs = joinPoint.getArgs();
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Authority authority = signature.getMethod().getAnnotation(Authority.class);
        for(Object argItem : objs) {
            System.out.println("---->now-->argItem:" + argItem);
            JSONObject json = JSONObject.parseObject(JSONObject.toJSONString(argItem));
            Object roleId = json.get(authority.roleIdField());
            if (roleId != null) {
                // 获取机构ID列表
                if(authority.queryDepartmentIdList()) {
//                    JSONObject jsonObject = departmentServiceFeign.getSubDeptIdsByRoleId(roleId.toString());
//                    if (jsonObject != null) {
//                        if (jsonObject.get("code") != null && jsonObject.getString("code").equals(ReturnMsg.SUCCESS.getCode())) {
//                            JSONObject data = jsonObject.getJSONObject("data");
//                            if (argItem instanceof AuthorityListReq) {
//                                AuthorityListReq baseReq = (AuthorityListReq) argItem;
//                                baseReq.setDepartmentIdList((List<String>)data.get("deptIds"));
//                            }
//                        }
//                    }
                }

                // 获取顶级机构ID
                if(authority.queryDepartmentTopId()){
//                    JSONObject jsonObject = departmentServiceFeign.getTopDeptByRoleId(roleId.toString());
//                    if (jsonObject != null) {
//                        if (jsonObject.get("code") != null && jsonObject.getString("code").equals(ReturnMsg.SUCCESS.getCode())) {
//                            JSONObject data = jsonObject.getJSONObject("data");
//                            if (argItem instanceof AuthorityListReq) {
//                                AuthorityListReq baseReq = (AuthorityListReq) argItem;
//                                baseReq.setAuthorityDepartmentTopId(data.getString("deptId"));
//                            }
//                        }
//                    }
                }

            }
            System.out.println("---->after-->argItem:" + argItem);
        }
        return joinPoint.proceed(objs);
    }

}
