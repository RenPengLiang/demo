package com.cjkj.base.dto.req.list;

import com.cjkj.base.dto.req.PageReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@ApiModel("企业信息->查询条件")
public class EnterpriseInfoListReq extends PageReq {

    /**
     * 维修厂机构ID
     */
    @ApiModelProperty("维修厂机构ID")
    private String departmentId;

    /**
     * 名称
     */
    @ApiModelProperty("名称")
    private String name;

    /**
     * 企业类型（1：维修厂，2：承运商）
     */
    @ApiModelProperty("企业类型（1：维修厂，2：承运商）")
    private String enterpriseType;

    /**
     * 营业执照号
     */
    @ApiModelProperty("营业执照号")
    private String businessLicense;

    /**
     * 省
     */
    @ApiModelProperty("省")
    private String province;

    /**
     * 市
     */
    @ApiModelProperty("市")
    private String city;

    /**
     * 县
     */
    @ApiModelProperty("县")
    private String county;

    /**
     * 详细地址
     */
    @ApiModelProperty("详细地址")
    private String address;
    /**
     * 是否有效
     */
    @ApiModelProperty("是否有效")
    private String effective;
}