package com.cjkj.base.util;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description: 静态参数
 */
public class BaseStatusStatic {

    /**
     * 有效，启用
     */
    public static final String Y="Y";
    /**
     * 无效，禁用
     */
    public static final String N="N";
    /**
     * 地区（大区）
     */
    public static final String REGION="1";

    /**
     * 省
     */
    public static final String PROVINCE="2";

    /**
     * 市
     */
    public static final String CITY="3";

    /**
     * '北京市','天津市','重庆市','上海市' 直辖市特殊处理
     */
    public static final String SPECIAL_CITY="110000,120000,500000,310000";

    /**
     * 批量分割的时候，默认1000条分割一次
     */
    public static final int BATCH_SIZE=1000;
}
