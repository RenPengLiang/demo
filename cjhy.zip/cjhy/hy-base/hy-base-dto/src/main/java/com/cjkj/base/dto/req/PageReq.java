package com.cjkj.base.dto.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
public class PageReq {
    @ApiModelProperty("当前页数；默认第一页")
    private int pageNum = 0;
    @ApiModelProperty("每页个数;默认20条")
    private int pageSize = 20;
}
