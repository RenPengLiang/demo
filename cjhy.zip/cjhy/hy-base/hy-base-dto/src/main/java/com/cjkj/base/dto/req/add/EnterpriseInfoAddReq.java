package com.cjkj.base.dto.req.add;

import com.cjkj.base.dto.req.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@ApiModel("企业信息->新增")
public class EnterpriseInfoAddReq extends BaseReq {

    /**
     * 维修厂机构ID
     */
    @ApiModelProperty("维修厂机构ID")
    private String departmentId;

    /**
     * 名称
     */
    @ApiModelProperty("名称")
    @NotBlank(message="名称不能为空！")
    private String name;

    /**
     * 企业类型（1：维修厂，2：承运商）
     */
    @ApiModelProperty("企业类型（1：维修厂，2：承运商）")
    private String enterpriseType;

    /**
     * 联系人
     */
    @ApiModelProperty("联系人")
    @NotBlank(message="联系人不能为空！")
    private String contacts;

    /**
     * 联系电话
     */
    @ApiModelProperty("联系电话")
    @NotBlank(message="联系电话不能为空！")
    private String contactsTel;

    /**
     * 法人
     */
    @ApiModelProperty("法人")
    private String legalPerson;

    /**
     * 营业执照号
     */
    @ApiModelProperty("营业执照号")
    private String businessLicense;

    /**
     * 省
     */
    @ApiModelProperty("省")
    @NotBlank(message="省不能为空！")
    private String province;

    /**
     * 省
     */
    @ApiModelProperty("省")
    @NotBlank(message="省名称不能为空！")
    private String provinceName;

    /**
     * 市
     */
    @ApiModelProperty("市")
    @NotBlank(message="市不能为空！")
    private String city;

    /**
     * 市
     */
    @ApiModelProperty("市")
    @NotBlank(message="市名称不能为空！")
    private String cityName;

    /**
     * 县
     */
    @ApiModelProperty(value = "县",hidden = true)
    private String county;

    /**
     * 详细地址
     */
    @ApiModelProperty("详细地址")
    @NotBlank(message="详细地址不能为空！")
    private String address;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    private BigDecimal lng;

    /**
     * 坐标系
     */
    private String coordinate;

    /**
     * 纬度
     */
    @ApiModelProperty("纬度")
    private BigDecimal lat;

    /**
     * 是否有效
     */
    @ApiModelProperty("是否有效，开启，关闭")
    @NotBlank(message="是否开启不能为空！")
    private String effective;

    /**
     * 开户行
     */
    @ApiModelProperty("开户行")
    @NotBlank(message="开户行不能为空！")
    private String bank;

    /**
     * 开户行账号
     */
    @ApiModelProperty("开户行账号")
    @NotBlank(message="开户行账号不能为空！")
    private String bankNo;
}