package com.cjkj.base.feign;

import com.alibaba.fastjson.JSONObject;
import com.cjkj.base.feign.impl.UserInfoFeignImpl;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <strong>Title : IUserInfoServiceFeign</strong><br>
 * <strong>Description : 调用其他微服务Service</strong><br>
 * <strong>Create on : 2019-04-02</strong><br>
 *
 * @author renpl<br>
 */
@FeignClient(name = "cjkj-usercenter-service", fallback = UserInfoFeignImpl.class)
public interface IUserInfoServiceFeign {

    @GetMapping(value = "/sys/user/info")
    String getUserInfo(@RequestParam(value = "userId") String userId);

    /**
     * 返回查询当前登录用户以外的所有机构
     *
     * @return
     */
    @GetMapping(value = "/feign/sys/dept/infos/{menuId}")
    String getDeptsByNoUserInfo(@RequestParam(value = "menuId") String menuId);

    /**
     * 查询所有的公司
     * @return
     */
    @GetMapping(value = "/feign/sys/dept/listCompany")
    String listCompany();

    /**
     * 根据userId查询登录用户的信息
     *
     * @param userId
     * @return
     */
    @GetMapping(value = "/sys/user/info/{userId}")
    String getUserInfoByUserId(@RequestParam(value = "userId") String userId);

    /**
     * 获取当前登录用户所属机构以及机构下所有用户信息
     *
     * @return
     */
    @GetMapping(value = "/sys/user/infos/{userId}/{deptId}")
    String getUserInfoAndDept(@RequestParam(value = "userId") String userId, @RequestParam(value = "deptId") String deptId);

    /**
     * 根据deptId和token查询组织机构信息
     *
     * @param deptId
     * @return
     */
    @GetMapping(value = "/sys/dept/info/{deptId}")
    String getDeptInfoById(@RequestParam(value = "deptId") String deptId);

    /**
     * 获取当前登录用户的顶级部门
     * @param userId
     * @return
     */
    @GetMapping(value = "/sys/user/getTopDeptId/{userId}")
    String getTopDeptId(@RequestParam(value = "userId") String userId);

    /**
     * 获取拥有权限的部门ID列表
     * @param userId
     * @return
     */
    @GetMapping(value = "/sys/user/getAllRoleDeptId/{userId}")
    String getAllRoleDeptId(@RequestParam(value = "userId") String userId);

    /**
     * 根据角色查询角色对应的顶级部门Id
     * @param roleId
     * @return
     */
    @GetMapping(value = "/sys/dept/queryCompanyByRoleId/{roleId}")
    JSONObject queryCompanyByRoleId(@RequestParam(value = "roleId") String roleId);

    /**
     * 根据用户姓名查询用户信息
     * @param userName
     * @return
     */
    @GetMapping(value = "/sys/user/getLoginUserByName/{userName}")
    JSONObject getLoginUserByName(@RequestParam(value = "userName") String userName);
}
