package com.cjkj.base.service;

import com.cjkj.base.entity.BaseResources;
import com.cjkj.common.service.ISuperService;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
public interface BaseResourcesService extends ISuperService<BaseResources> {

}