package com.cjkj.base.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: RenPL
 * @Date: 2020/11/30 9:29
 * @Description:
 */
@Data
@TableName("base_resources")
public class BaseResources implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 主键
     */
    @TableId(type = IdType.ID_WORKER_STR)
    private String id;

    /**
     * 类型
     */
    private String typeName;

    /**
     * 第三方ID
     */
    private String otherId;

    /**
     * 第三方类型
     */
    private String otherType;

    /**
     * 资源ID
     */
    private String resourcesId;

    /**
     * 资源地址
     */
    private String resourcesUrl;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 创建人名称
     */
    private String createdByName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    /**
     * 更新人
     */
    private String updatedBy;

    /**
     * 更新人名称
     */
    private String updatedByName;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.UPDATE)
    private Date updateTime;
}